<template>
  <div class="text-gray-400 text-center mt-20 text-lg">請從上方選單選擇一個功能</div>
</template>
